### Crypto Analysis using CryptoCompare

[README](https://docs.google.com/document/d/1cxqU0d6jLgmjK3pTIK_nI7M9fo7NDUt3qGktD8knNZ8/edit)